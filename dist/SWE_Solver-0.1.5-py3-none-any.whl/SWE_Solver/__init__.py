from .post_processing import plotSWE
from .examples import exampleSWE